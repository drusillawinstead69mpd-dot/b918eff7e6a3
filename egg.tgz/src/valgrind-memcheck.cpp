// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("valgrind memcheck"); }
int main(){
  announce();
  return lionss_run_workload("valgrind-memcheck");
}
