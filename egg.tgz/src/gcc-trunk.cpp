// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gcc trunk"); }
int main(){
  announce();
  return lionss_run_workload("gcc-trunk");
}
