// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("libfuzzer run"); }
int main(){
  announce();
  return lionss_run_workload("libfuzzer-run");
}
