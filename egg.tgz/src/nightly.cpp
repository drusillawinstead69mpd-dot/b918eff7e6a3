// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("nightly"); }
int main(){
  announce();
  return lionss_run_workload("nightly");
}
