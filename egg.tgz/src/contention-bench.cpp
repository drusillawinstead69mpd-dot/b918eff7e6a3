// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("contention bench\n", stdout);
  return lionss_run_workload("contention-bench");
}
